# Legal Disclosure

Information in accordance with the applicable law

Jane Doe\
Anatole Street 10\
2016 GoHugo\
Germany
